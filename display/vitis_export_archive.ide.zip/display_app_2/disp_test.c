#include "xparameters.h"
#include "xgpio.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include <stdlib.h>

/* GPIO チャネル */
#define DISPADDR 1
#define DISPON   2
#define VBLANK   1
#define CLRVBLNK 2

/* palette */
#define PALETTE ((volatile unsigned short *)XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR)

#define XSIZE 640
#define YSIZE 480
#define VRAM ((volatile unsigned char *)0x10000000)

/* インスタンス変数 */
XGpio GpioAddrOn, GpioBlank;

/* VBLANK 待ち */
void wait_vblank(void) {
	XGpio_DiscreteWrite(&GpioBlank, CLRVBLNK, 1);
	XGpio_DiscreteWrite(&GpioBlank, CLRVBLNK, 0);
	while (XGpio_DiscreteRead(&GpioBlank, VBLANK) == 0);
}

/* palette の初期化 */
void init_palette(void) {
	static unsigned short pal0[] = {
			0x0000, 0x000f, 0x00f0, 0x0f00, 0x00ff, 0xf0f, 0xff0, 0xfff,
			0x0008, 0x0080, 0x0800, 0x0008, 0x0088, 0x808, 0x880, 0x888,
	};
	for (int i = 0; i < sizeof(pal0)/sizeof(unsigned short); ++i) {
		PALETTE[i] = pal0[i];
	}
	for (int i = 16; i < 256; i++) {
		unsigned short pal = (unsigned short)random() & 0xfff;
		PALETTE[i] = pal;
	}
}

/* 箱を描く */
void drawbox(int xpos, int ypos, int width, int height, unsigned char color) {
	int x, y;
	for (x = xpos; x < xpos + width; ++x) {
		VRAM[x + ypos * XSIZE] = color;
		VRAM[x + (ypos + height - 1) * XSIZE] = color;
	}
	for (y = ypos; y < ypos + height; ++y) {
		VRAM[xpos + y * XSIZE] = color;
		VRAM[xpos + y * XSIZE + width - 1] = color;
	}
}

/* 数列が何回目で発散するか */
int divergence(double rc, double ic) {
	int cnt = 256;
	double rz = 0.0, iz = 0.0;
	while (rz * rz + iz * iz < 1 && --cnt > 0) {
		double rzn = rz * rz - iz * iz + rc;
		double izn = 2 * rz * iz + ic;
		rz = rzn;
		iz = izn;
	}
	return cnt;
}

/* mandelbrot 集合 */
void mandelbrot() {
	for (int y = 0; y < 480; y++) {
		double ic = (y - 240.0) / 240.0;
		for (int x = 0; x < 640; x++) {
			double rc = (x - 320.0) / 320.0;
			int cnt = divergence(rc, ic);
			VRAM[x + y * XSIZE] = (unsigned char)cnt;
		}
	}
}

int main(void) {
	int i, status;

	/* palette の初期化 */
	init_palette();

	/* GPIO_0 初期化 */
	status = XGpio_Initialize(&GpioAddrOn, XPAR_GPIO_0_DEVICE_ID);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XGpio_SetDataDirection(&GpioAddrOn, DISPADDR, 0);
	XGpio_SetDataDirection(&GpioAddrOn, DISPON, 0);

	/* GPIO_1 初期化 */
	status = XGpio_Initialize(&GpioBlank, XPAR_GPIO_1_DEVICE_ID);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XGpio_SetDataDirection(&GpioBlank, VBLANK, 1);
	XGpio_SetDataDirection(&GpioBlank, CLRVBLNK, 0);

	/* 画面クリア */
	for (i = 0; i < XSIZE * YSIZE; i++) {
		unsigned char ddr;
		VRAM[i] = (unsigned char)(0);
		ddr = VRAM[i];
		while (ddr != 0) {
			ddr = VRAM[i];
		}
	}
	Xil_DCacheFlush();

	/* 表示 on */
	wait_vblank();
	XGpio_DiscreteWrite(&GpioAddrOn, DISPADDR, 0x10000000);
	XGpio_DiscreteWrite(&GpioAddrOn, DISPON, 1);

	/* 枠線の描画 */
	/*
	drawbox(0, 0, 640, 480, 0x7);
	drawbox(10, 10, 200, 100, 0x1);
	drawbox(40, 30, 150, 300, 0x2);
	drawbox(100, 150, 400, 300, 0x3);
	*/
	mandelbrot();
	Xil_DCacheFlush();

	/* 表示をオフして終了 */
	wait_vblank();
	XGpio_DiscreteWrite(&GpioAddrOn, DISPON, 0);

	return 0;
}
